package androidexample.com.deadlike;

import android.app.Application;

import java.io.FileInputStream;
import java.util.Date;

/**
 * Created by Hung on 3/27/2018.
 */
public class MyApplication extends Application {

    public final int MAX_SUBJECT_NAME = 50;
    public final int MAX_DEADLINE_NAME = 50;
    public static int NOTI_ID = 1;

    @Override
    public void onCreate(){

        super.onCreate();
        loadDeadlineList();
    }

    private void loadDeadlineList(){
        FileInputStream in;
        String filename = "deadlist.dat";
        try{
            in = openFileInput(filename);
            readFromFile(in);
            in.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void readFromFile(FileInputStream inputStream){
        int bufferSize = MAX_DEADLINE_NAME + MAX_SUBJECT_NAME + 6;

        byte[] buffer = new byte[bufferSize];
        int count = 0;
        String deadlineName,
                subjectName;
        int dd, mm, yyyy, hh, min;
        try{
            while(inputStream.available() > 0){
                inputStream.read(buffer, 0, bufferSize);
                deadlineName = new String(buffer, 0, MAX_DEADLINE_NAME).trim();

                int t = MAX_DEADLINE_NAME+1;

                dd = buffer[t];
                t+=1;

                mm = buffer[t];
                t+=1;

                yyyy = buffer[t];
                t+=1;

                hh = buffer[t];
                t+=1;

                min = buffer[t];
                t+=1;

                subjectName = new String(buffer, t, MAX_SUBJECT_NAME).trim();


                Deadline temp = new Deadline(new Date(yyyy, mm,dd, hh, min), subjectName, deadlineName);
            }

        }catch (Exception e){
            e.printStackTrace();
        }

    }

}

