package androidexample.com.deadlike;

import android.content.Context;
import android.widget.ArrayAdapter;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * Created by Hung on 3/26/2018.
 */
public class Deadline {
    public String deadlineName;
    public Date end;
    public String subjectName;
    public String description;

    private static Calendar cal = Calendar.getInstance();


    private static ArrayList<Deadline> deadlineList = new ArrayList<Deadline>();
    private static final String pattern = new String("dd/MM/yyyy");
    private final int MAX_SUBJECT_NAME = 50;
    private final int MAX_DEADLINE_NAME = 50;

    public static ArrayList<Deadline> getDeadlineList(){
        return deadlineList;
    }

    private Deadline(){};
    public Deadline(Date end, String subjectName
                    /*String description*/, String deadlineName){
        this.end = end;
        this.subjectName = subjectName;
        this.deadlineName = deadlineName;
        /*if(description != null)
            this.description = description;
        */
        if(deadlineList == null){
            deadlineList = new ArrayList<Deadline>();
        }
        addToDeadlineList(this);

    }

    private void addToDeadlineList(Deadline curDeadline){
        //Sap xep theo thu tu thoi gian, cang som thi dung truoc

        if(deadlineList.isEmpty()){
            deadlineList.add(curDeadline);
            return;
        }
        for (int i = 0; i < deadlineList.size(); i++) {
            Deadline deadline = deadlineList.get(i);
            if(deadline.end.compareTo(curDeadline.end) > 0){
                deadlineList.add(i, curDeadline);

                return;
            }
        }

        deadlineList.add(curDeadline);

    }

    public String getEndDate(){

        DateFormat df = new SimpleDateFormat(pattern);

        String endDay = df.format(end);
        return endDay;
    }

    private void writeToFile(FileOutputStream outputStream){
        try{
            byte[] buffer = deadlineName.getBytes();

            int len = buffer.length;
            outputStream.write(buffer, 0, len);
            for(int i = 0; i < MAX_DEADLINE_NAME - len + 1; i++){
                      outputStream.write(0);
            }


            buffer = new byte[1];
            cal.setTime(end);
            int value = cal.get(Calendar.DAY_OF_MONTH);
            buffer[0] = (byte) (value);
            outputStream.write(buffer);


            value = cal.get(Calendar.MONTH);
            buffer[0] = (byte) (value);
            outputStream.write(buffer);

            value = cal.get(Calendar.YEAR);
            buffer[0] = (byte) (value - 1900);
            outputStream.write(buffer);

            value = cal.get(Calendar.HOUR_OF_DAY);
            buffer[0] = (byte) (value - 1);
            outputStream.write(buffer);

            value = cal.get(Calendar.MINUTE);
            buffer[0] = (byte) (value);
            outputStream.write(buffer);

            buffer = subjectName.getBytes();
            len = buffer.length;
            outputStream.write(buffer, 0, len);
            for(int i = 0; i < MAX_SUBJECT_NAME - len; i++){
                outputStream.write(0);
            }

        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void updateDeadlineList(Context context){

        String filename = "deadlist.dat";
        FileOutputStream outputStream;

        try {
            outputStream = context.openFileOutput(filename, Context.MODE_PRIVATE);
            for(Deadline d : Deadline.getDeadlineList()){
                d.writeToFile(outputStream);
            }
            outputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
    public int getPos(){
        return deadlineList.indexOf(this);

    }

}
