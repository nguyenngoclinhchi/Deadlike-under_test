package androidexample.com.deadlike;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

import java.io.File;
import java.io.FileInputStream;
import java.util.Date;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void openInputScreen(View view){
        Intent intent = new Intent(this, InputActivity.class);
        startActivity(intent);
    }

    public  void openOutputScreen(View view){
        Intent intent = new Intent(this, OutputActivity.class);
        startActivity(intent);
    }


    /*//-------------------------------------------------------------------------------------------
    public void notifyPendingIntent(View view) {

        NotificationCompat.Builder myNotification = new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.my_notification_icon)
                .setContentText("Calling 021-12345678")
                .setContentTitle("Phone Call Notification");

        Intent phoneCall = new Intent(Intent.ACTION_CALL);
        phoneCall.setData(Uri.parse("tel:021-12345678"));
        PendingIntent phoneCallIntent = PendingIntent.getActivity(this, 0, phoneCall, PendingIntent.FLAG_UPDATE_CURRENT);

        myNotification.setContentIntent(phoneCallIntent);

        NotificationManager mNotificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.notify(0, myNotification.build());

    }*/


}
