package androidexample.com.deadlike;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;

import java.io.FileOutputStream;
import java.util.Calendar;
import java.util.Date;
import java.lang.Integer;
public class InputActivity extends AppCompatActivity {

    private static String CUSTOM_ACTION = "androidexample.com.deadlike.DEADLINE_NOTI";
    private static Calendar cal;
    private static AlarmManager alarmManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cal = Calendar.getInstance();
        EditText description_editText = (EditText) findViewById(R.id.description_EditText);


        setContentView(R.layout.activity_input);

    }

    public void submit(View view){
        EditText deadlineName_editText = (EditText) findViewById(R.id.deadlineName_editText);

        Date end = getDate();
        if(end == null){
            return;
        }
        EditText subjectName_editText = (EditText) findViewById(R.id.subjectName_editText);
        //EditText description_editText = (EditText) findViewById(R.id.description_EditText);



        Deadline newDeadline = new Deadline(
            end, subjectName_editText.getText().toString(),
                deadlineName_editText.getText().toString()
        );
        Deadline.updateDeadlineList(this);
        setNotification(newDeadline);
        //---------------------------------------------------
        Intent intent = new Intent(this, OutputActivity.class);
        startActivity(intent);
    }

    private void test(){
        Intent intent = new Intent(this, NotificationReceiver.class);
        intent.setAction(CUSTOM_ACTION);
        intent.setType("text/plain");
        intent.putExtra("d_name", "Hung");
        intent.putExtra("s_name", "Vinh");
        intent.putExtra("deadtime", "17-12-1999");

        PendingIntent pendingIntent = PendingIntent.getBroadcast
                (InputActivity.this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager = (AlarmManager) InputActivity.this.getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, cal.getInstance().getTimeInMillis(), pendingIntent);


    }


    private void setNotification(Deadline d){
        Intent intent = new Intent(this, NotificationReceiver.class);
        intent.setAction(CUSTOM_ACTION);
        intent.setType("text/plain");
        intent.putExtra("pos", d.getPos());

        cal.setTime(d.end);


        PendingIntent pendingIntent = PendingIntent.getBroadcast
                (InputActivity.this, 3, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        if(alarmManager == null)
            alarmManager = (AlarmManager) InputActivity.this.getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pendingIntent);

    }

    private Date getDate(){
        int dd, mm, yyyy, hh, min;
        Date end;
        EditText dd_editText = (EditText) findViewById(R.id.dd_editText);
        EditText mm_editText = (EditText) findViewById(R.id.mm_editText);
        EditText yyyy_editText = (EditText) findViewById(R.id.yyyy_editText);
        EditText hh_editText = (EditText) findViewById(R.id.hh_editText);
        EditText min_editText = (EditText) findViewById(R.id.min_editText);
        try{
            dd = Integer.parseInt(dd_editText.getText().toString());
            mm = Integer.parseInt(mm_editText.getText().toString());
            yyyy = Integer.parseInt(yyyy_editText.getText().toString());
            hh = Integer.parseInt(hh_editText.getText().toString());
            min = Integer.parseInt(min_editText.getText().toString());

            end = new Date(yyyy - 1900, mm - 1, dd, hh, min);

            return end;
        }
        catch (Exception e){
            e.printStackTrace();
        }


        return null;

    }

}
