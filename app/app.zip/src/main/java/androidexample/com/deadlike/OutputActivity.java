package androidexample.com.deadlike;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.io.Console;
import java.io.FileInputStream;
import java.util.Date;
import java.util.logging.ConsoleHandler;

public class OutputActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_output);
        final DeadlineAdapter adapter = new DeadlineAdapter(this, R.layout.deadline_layout, Deadline.getDeadlineList());

        ListView deadlineListView = (ListView) findViewById(R.id.deadlineListView);

        deadlineListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position,
                                    long id) {
                adapter.remove(adapter.getItem(position));
                updateFile();
            }
        });

        deadlineListView.setAdapter(adapter);

    }

    void updateFile(){
        Deadline.updateDeadlineList(this);
        //Update view

    }

}
